package com.choongang;

import java.util.ArrayList;
import java.util.List;

public class K_clearArrayList {
    public ArrayList<Integer> clearArrayList(ArrayList<Integer> arrayList) {
        // TODO:입력받은 ArrayList의 모든 요소를 삭제한 뒤
        //  해당 ArrayList를 리턴해야 합니다.
         arrayList.clear();
        return arrayList;
    }
}
