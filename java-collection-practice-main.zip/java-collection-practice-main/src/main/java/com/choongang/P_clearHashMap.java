package com.choongang;

import java.util.HashMap;

public class P_clearHashMap {
    public void clearHashMap(HashMap<Integer, Boolean> hashMap) {
        // TODO:<Integer, Boolean> 타입을 요소로 가지는 HashMap을 입력받아
         //모든 Entry를 제거합니다.
  hashMap.clear();
    }
}
