package com.choongang;

import java.util.HashMap;

public class Q_getSize {
    public int getSize(HashMap<Integer, Integer> hashMap) {
        // TODO:<Integer, Integer> 타입을 요소로 가지는 HashMap을 입력받아
        //  Entry의 개수를 출력합니다.
        System.out.println(hashMap.size());
        return hashMap.size();
    }
}
