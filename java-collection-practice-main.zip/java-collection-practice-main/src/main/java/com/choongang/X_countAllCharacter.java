package com.choongang;

import java.util.HashMap;

public class X_countAllCharacter {
    public HashMap<Character, Integer> countAllCharacter(String str) {
        // TODO:문자열을 입력받아
        //  문자열을 구성하는 각 문자(letter)를 키로 갖는 HashMap을 리턴해야 합니다.
         //각 키의 값은 해당 문자가 문자열에서 등장하는 횟수를 의미하는 int 타입의 값이어야 합니다.
       //문자열 -> 문자 -> 키 -> <문자,문자포함갯수>
        HashMap<Character, Integer> map = new HashMap<>();
        if (0 > str.length()){
            return null;
        }
        int count = 0;

char[] strCount = str.toCharArray();
        for(int i=0; i<str.length(); i++) {
            if(str.charAt(i) == strCount[i]) count++;
        }
        for(int i=0; i<str.length(); i++){
            map.put(str.charAt(i),count);
        }


            return map;
    }
}
