package com.choongang;

import java.util.HashMap;

public class T_isContain {
    public boolean isContain(HashMap<String, Integer> hashMap, String key) {
        // TODO:<String, Integer> 타입을 요소로 가지는 HashMap과 문자열을 입력받아,
        //  HashMap에 문자열을 key로 한 Entry가 있는지의 여부를 리턴해야 합니다.


        return hashMap.containsKey(key);
    }
}
