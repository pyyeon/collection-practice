package com.choongang;

import java.util.HashMap;

public class W_select {
    public HashMap<String, Integer> select(String[] arr, HashMap<String, Integer> hashMap) {
        // TODO:String 타입을 요소로 가지는 배열과 <String, Integer> 타입을 요소로 가지는 HashMap을 입력받아,
        //  배열의 각 요소들을 HashMap의 키로 했을 때
        //  그 값을 추출하여 만든 새로운 HashMap을 리턴해야 합니다.
// hashmap<문자열,정수> 여기에 배열 요소""를 키로 입력
        HashMap<String, Integer> map = new HashMap<>();
     for (int i = 0; i <= arr.length -1; i++) {
         if (hashMap.containsKey(arr[i])) {//배열요소가 키로 존재한다면
             map.put(arr[i], hashMap.get(arr[i]));
         }
     }
        return map;
    }
}
