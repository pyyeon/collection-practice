package com.choongang;

import java.util.ArrayList;

public class A_makeArrayList {
    public ArrayList<Integer> makeArrayList() {
        // TODO:ArrayList를 선언하고 1부터 5까지 담은 뒤 리턴해야 합니다.
ArrayList<Integer> arrayList = new ArrayList<>();
arrayList.add(1);
        arrayList.add(2);
        arrayList.add(3);
        arrayList.add(4);
        arrayList.add(5);

        return arrayList;
    }
}
