package com.choongang;

import java.util.HashMap;
import java.util.Map;

public class S_addFullNameEntry {
    public HashMap<String, String> addFullNameEntry(HashMap<String, String> hashMap) {
        // TODO:한 사람의 firstName, lastName Entry가 저장되어있는 HashMap을 입력 받아,
        //  fullName 이라는 새 Entry를 HashMap에 저장하고
        //  해당 HashMap을 리턴해야 합니다.
        String firstName = hashMap.get("firstName");
        String lastName = hashMap.get("lastName");


        String fullName = firstName + lastName;

        hashMap.put("fullName", fullName);


        return hashMap;
    }
}