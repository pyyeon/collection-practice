package com.choongang;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class M_getValue {
    public Integer getValue(HashMap<String, Integer> hashMap, String key) {
        // TODO:<String, Integer> 타입을 요소로 가지는 HashMap과 키를 입력받아,
        //  키에 해당하는 값을 리턴해야 합니다.



        return hashMap.get(key);
    }
}
