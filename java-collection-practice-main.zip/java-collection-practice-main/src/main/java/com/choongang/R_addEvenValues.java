package com.choongang;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class R_addEvenValues {
    public int addEvenValues(HashMap<Character, Integer> hashMap) {
        // TODO:<Character, Integer> 타입을 요소로 가지는 HashMap을 입력받아
        //  짝수 값(Value) 끼리 모두 더한 값을 리턴해야 합니다.
        int answer = 0;
        for (int x : hashMap.keySet()) {
            if (hashMap.get(x) % 2 == 0) {
                answer += x;
            }


        }
        return answer;
    }
}
