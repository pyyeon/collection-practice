package com.choongang;

import java.util.*;

public class U_getElementOfListEntry {
    public String getElementOfListEntry(HashMap<String, List<String>> hashMap, String key, int index) {
        // TODO:List를 value로 가지는 HashMap, key, 인덱스를 입력받아,
        //  key에 해당하는 키(key)가 존재하는 경우, index가 가리키는 List의 요소를 리턴해야 합니다
       //주어진 수가 List의 범위를 벗어나지 않는 경우에만 List의 요소를 리턴해야 합니다.
            if (hashMap.containsKey(key)){
                if (index <= (hashMap.get(key)).size()-1){
                return (hashMap.get(key)).get(index);
            }else{
                return null;
            }
    }else{
        return null;
    }
}}



//if (index < (hashMap.get(key)).size()-1)//주어진 수가 List의 범위를 벗어나지 않는 경우에만 List의 요소를 리턴해야 합니다.
//       if (hashMap.containsKey(key)){
//           return (hashMap.get(key)).get(index);
//       }else{
//           return null;
//       }
//
//    }else{
//        return null;
//    }
//}
//<String, List<String>>
//<key,List>    index < hashmap.get(list.size()-1))